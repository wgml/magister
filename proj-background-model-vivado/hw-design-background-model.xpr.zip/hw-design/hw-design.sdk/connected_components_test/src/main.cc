#include <opencv2/opencv.hpp>
#include <ctime>

int main(int argc, char* argv[])
{

	cv::Mat input_image = cv::imread(argv[1], cv::IMREAD_GRAYSCALE);
	cv::Mat binary;
	cv::threshold(input_image, binary, 200, 255, 0);

	cv::imwrite("binary.png", binary);

	cv::Mat labels, stats, centroids;

	std::clock_t begin = std::clock();
	cv::connectedComponents(binary, labels);
	std::clock_t intermediate = std::clock();
	int num_labels = cv::connectedComponentsWithStats(binary, labels, stats, centroids);
	std::clock_t end = std::clock();
	std::cerr << "#labels = " << num_labels << " Labelling took " << double(intermediate - begin) / CLOCKS_PER_SEC
			<< "s. With stats it took " << double(end - intermediate) / CLOCKS_PER_SEC << "s." << std::endl;
	cv::imwrite("components.png", labels);

	for (int l = 1; l < num_labels; l++)
	{
		std::cerr << "#" << l << "(x,y) = (" << centroids.at<long double>(l, 0) << ", " << centroids.at<long double>(l, 1) << ")" << std::endl;
	}

	return 0;
}
