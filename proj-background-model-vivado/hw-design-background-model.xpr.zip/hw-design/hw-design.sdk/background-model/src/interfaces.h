#define vdma_background_buffer_addr 0x43000000
#define vdma_frame_buffering_addr	0x43100000
#define vdma_result_frame_addr		0x43400000
#define algorithm_parameters_addr	0x43300000
#define axi_gpio_hpd_addr			0x43200000
